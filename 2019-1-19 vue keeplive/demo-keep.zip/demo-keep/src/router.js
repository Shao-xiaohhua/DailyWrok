import Vue from 'vue'
import Router from 'vue-router'
import Example from './views/example.vue'
import demo from './views/demo.vue'
import one from './views/one.vue'
import two from './views/two.vue'
import three from './views/three.vue'
import four from './views/four.vue'

Vue.use(Router)

export default new Router({
  routes: [{
      path: '/',
      name: 'example',
      component: Example
    },
    {
      path: '/demo',
      name: 'demo',
      component: demo,
      children: [{
          path: '/one',
          name: 'one',
          component: one,
          meta:{
            keepAlive:true //需要被缓存的组件
         },
        },
        {
          path: '/two',
          name: 'two',
          component: two,
          meta:{
            keepAlive:true //需要被缓存的组件
         },
        },
        {
          path: '/three',
          name: 'three',
          component: three,
          meta:{
            keepAlive:true //需要被缓存的组件
         },
        },
        {
          path: '/four',
          name: 'four',
          component: four,
          meta:{
            keepAlive:true //需要被缓存的组件
         },
        },
      ]
    }
  ],
  scrollBehavior (to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      if (from.meta.keepAlive) {
        from.meta.savedPosition = document.body.scrollTop
      }
      return { x: 0, y: to.meta.savedPosition || 0 }
    }
  }
})
