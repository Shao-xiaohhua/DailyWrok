<template>
  <div class="model-wrap">
    <section class="side-l">
      <a
        @click="itemClick(item,index)"
        v-for="(item,index) in itemList"
        :key="index"
        class="item"
        :class="{ active: active === index }"
        :href="item.url"
      >{{ item.name }}</a>
    </section>
    <section class="side-r">
      <header class="clearfix">
        <a
          @click.stop="active = index"
          v-for="(item,index) in itemHistory"
          :key="index"
          class="item pull-left"
          :class="{ active: active === index }"
          :href="item.url"
        >{{ item.name }}
          <span @click.stop="remove(index)">x</span>
        </a>
      </header>
      <div class="view-warp">
        <keep-alive>
          <router-view v-if="this.$route.meta.keepAlive"></router-view>
        </keep-alive>
      </div>
    </section>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';
export default {
  components: {},
  name: 'model',
  data() {
    return {
      active: 0,
      itemList: [
        { name: '导航一', url: '#/one' },
        { name: '导航二', url: '#/two' },
        { name: '导航三', url: '#/three' },
        { name: '导航四', url: '#/four' }
      ]
    };
  },
  methods: {
    ...mapActions(['AgetitemHistory', 'removeHistory']),
    itemClick(item, index) {
      this.active = index;
      this.AgetitemHistory(item);
    },

    remove(index) {
      this.active = index - 1;
      this.removeHistory(index);
    }
  },
  watch: {},
  computed: {
    ...mapGetters(['itemHistory'])
  },
  created() {},
  mounted() {
    let dom = document.querySelector('.model-wrap');
    dom.onscroll = function(e) {
      console.log(e);
    };
    window.addEventListener('scroll', function(e) {
      console.log(e);
    });
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss" rel="stylesheet/scss">
@import '../assets/scss/variables';
@import '../assets/scss/mixins';
@import '../assets/scss/common';
.model-wrap {
  width: 100%;
  height: 100%;
}
.side-l {
  float: left;
  width: 200px;
  height: 100%;
  .item {
    display: block;
    width: 100%;
    height: 30px;
    line-height: 30px;
    text-align: center;
    background-color: $blue;
    color: #fff;
    margin: 10px 0;
    &.active {
      background-color: $teal;
    }
  }
}
.side-r {
  position: absolute;
  left: 200px;
  right: 0;
  top: 0;
  bottom: 0;
  background-color: #f4f4f4;
  header {
    padding-top: 10px;
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #ccc;
    .item {
      position: relative;
      width: 80px;
      height: 100%;
      text-align: center;
      line-height: 50px;
      border-top: 1px solid #ccc;
      border-right: 1px solid #ccc;
      color: #fff;
      span {
        position: absolute;
        right: 3px;
        top: 3px;
        width: 20px;
        height: 20px;
        text-align: center;
        line-height: 20px;
        background-color: #ccc;
        border-radius: 50%;
      }
      &.active {
        background-color: red;
      }
    }
  }
  .view-warp {
    width: 100%;
    height: calc(100% - 60px);
    overflow: hidden;
  }
}
</style>