<template>
  <div class="model-wrap clearfix" @scroll="scro($event)" ref="bdscroll">
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';
export default {
  components: {},
  name: 'model',
  data() {
    return {
      scrolltop: 0
    };
  },
  methods: {
    ...mapActions([]),
    scro(e) {
      let top = this.$refs.bdscroll.scrollTop;
      // console.log(top)
      this.scrolltop = top;
      // console.log(this.scrolltop)
    }
  },
  watch: {},
  computed: {
    ...mapGetters([])
  },
  created() {},
  mounted() {
    console.log(this.scrolltop)
  },
  activated() {
    this.$refs.bdscroll.scrollTop = this.scrolltop;
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss" rel="stylesheet/scss">
@import '../assets/scss/variables';
@import '../assets/scss/mixins';
.model-wrap {
  width: 100%;
  overflow: scroll;
  li {
    margin: 20px;
    float: left;
    width: 150px;
    height: 300px;
    background-color: red;
  }
}
</style>