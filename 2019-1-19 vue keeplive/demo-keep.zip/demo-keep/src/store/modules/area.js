// import * as types from '../mutation-types'
import api from '@/api/index'
const state = {
  allNumber: 0,
  crfcode: '', // csrf token
  collection: '', // 公钥
  itemHistory: [
    { name: '导航一', url: './#/one' },
  ]
}

const getters = {
  allNumber: state => state.allNumber,
  crfcode: state => state.crfcode,
  collection: state => state.collection,
  itemHistory: state => state.itemHistory
}

const actions = {
  getAllNum: ({ commit },data) => commit('getAllNum',data),
  getLogin ({ commit }, data) { // 登录函数
    api.getDistrict(data).then(json => {
      console.log(json)
    })
  },
  AgetCrf ({commit}, inner) { // 获取token
    api.getCsrf().then(json => {
      commit('getCrf', json.data.result)
    })
  },
  AgetCollection ({commit}, inner) { // 获取公钥
    api.getColle().then(json => {
      commit('getCollection', json.data.result)
    })
  },
  AgetitemHistory ({commit}, data) {
    let arr =  state.itemHistory
    let index = arr.findIndex(e => e.url === data.url);
    if (index === -1) {
      arr.push(data)
    }
    commit('getitemHistory', arr)
  },
  removeHistory ({commit},index){
    let arr = state.itemHistory;
    arr.splice(index,1)
    commit('getitemHistory',arr);
  }
}


const mutations = {
  getAllNum(state, inner) {
    console.log(inner);
  },
  getCrf (state, inner) {
    state.crfcode = ''
    state.crfcode = inner
    console.log(inner)
  },
  getPasWord (state, inner) {
    return inner
  },
  getCollection (state, inner) {
    state.collection = ''
    state.collection = inner
    console.log(inner)
  },
  getitemHistory (state, inner) {
    state.itemHistory.inner
  }
}

export default {
  state,
  getters,
  actions,
  mutations
}
